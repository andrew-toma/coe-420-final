import React, {useState, useEffect} from 'react';
import './App.css';
import fire from './fire';
import Hero from './Hero'
import { FaFacebook } from "react-icons/fa";
import { IoLogoInstagram } from "react-icons/io";
import { IoLogoLinkedin } from "react-icons/io";
import { IoLogoTwitter } from "react-icons/io";
import { BiEnvelope } from "react-icons/bi";
import { FaUserAlt } from "react-icons/fa";
import { FaLock } from "react-icons/fa";

const App = () =>{
  const [user, setUser] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [hasAccount, setHasAccount] = useState('');

  const clearInputs = ()=>{
    setEmail('');
    setPassword('');

  }

  const clearErrors = ()=>{
    setEmailError('');
    setPasswordError('');

  }

  const handleLogin = ()=>{
  clearErrors();
  fire
    .auth()
    .signInWithEmailAndPassword(email,password)
    .catch(err =>{
      switch(err.code){
        case "auth/invalid-email":
        case "auth/user-disabled":
        case "auth/user-not-found":
          setEmailError(err.message);
          break;
        case "auth/wrong-password":
          setPasswordError(err.message);
          break;
      }
    });
  };

  const handleSignUp = ()=>{
    clearErrors();
    fire
      .auth()
      .createUserWithEmailAndPassword(email,password)
      .catch(err =>{
        switch(err.code){
          case "auth/email-already-in-use":
          case "auth/invalid-email":
            setEmailError(err.message);
            break;
          case "auth/weak-password":
            setPasswordError(err.message);
            break;
        }
      });
  };

  const handleLogout = () =>{
    fire.auth().signOut();
  };

  const authListener = () =>{
    fire.auth().onAuthStateChanged(user =>{
      if(user){
        clearInputs();
        setUser(user);
      }
      else{
        setUser("");
      }
    })
  }

  useEffect(()=>{
    authListener();
  })


  return (
    <div className="app">
      <div class="rectangle1">
       <div class="header">propertyVR</div>
      </div>
      
      {user ? (
        <Hero handleLogout={handleLogout}/>
      ):(
      <div class="login-box">
        <h1>Login</h1>
        <div class="textbox">
          <FaUserAlt class="logo"/>
          <input type="text" placeholder="Email" required value={email} onChange={e=>setEmail(e.target.value)}/>
          
         </div>
         <p className="errorMsg">{emailError}</p>
        <div class="textbox">
          <FaLock class="logo"/>
          <input type="password" placeholder="Password" required value={password} onChange={e=>setPassword(e.target.value)}/>
          
        </div>
        <p className="errorMsg" >{passwordError}</p>
        <div className="btnContainer">
          {hasAccount ? (
            <>
            <input onClick={handleLogin} class="btn" type="button"  name="" value="Sign in"/>
            <p>Don't have an account? <span onClick={() => setHasAccount(!hasAccount)}><a href="#" class="sign-up">Sign up</a></span></p>
            </>
          ):(
            <>
            <input onClick={handleSignUp} class="btn" type="button"  name="" value="Sign up"/>
            <p>Already have an account? <span  onClick={() => setHasAccount(!hasAccount)}><a href="#" class="sign-up">Sign in</a></span></p>
            </>
          )
          }
        </div>
        
      </div>
      )
      }
    
      <div class="rectangle2">
        <div>
        <a href="https://www.shaikhtech.com/"><img class="footer-logo" src="/images/Shaikh logo.png" alt=""/></a>
        <img class="footer-logo2" src="/images/matterport.png" alt=""/>
        </div>
        
       <div class="social">
        <ul>
        <li><a href="https://twitter.com/shaikhtech1"><IoLogoTwitter/></a></li>
        <li><a href="https://www.facebook.com/ShaikhTech-1478208639157188/?_rdc=1&_rdr"><FaFacebook/></a></li>
        <li><a href="https://www.instagram.com/shaikhtech/"><IoLogoInstagram/></a></li>
        <li><a href="https://www.linkedin.com/company/shaikhtech"><IoLogoLinkedin/></a></li>
        <li><a href="https://www.shaikhtech.com/contact/"><BiEnvelope/></a></li>
        </ul>
        </div>  

        <div class="copyright">
        propertyVR &copy; All rights reserved
        </div>

      </div>
  </div>
  );
}

export default App;
